public class ContaCorrente extends Conta{

    private float taxaOperacao;

    public boolean setTaxaOperacao(float taxaOperacao) {
        if ( taxaOperacao >= 0 && taxaOperacao <= 1){
            this.taxaOperacao = taxaOperacao;
            return true;
        }
        else return false;
    }

    public float getTaxaOperacao() { return taxaOperacao;}

    public ContaCorrente(float saldo, float taxaOperacao)
    {
        super(saldo);
        this.taxaOperacao = taxaOperacao;
    }

    @Override
    public boolean depositar(float valor) {
        if (valor >= 0)
        {
            setSaldo(saldo + valor);
            return setSaldo(saldo - (saldo * getTaxaOperacao()));
        }
        else {
            return false;
        }
    }

    @Override
    public boolean sacar(float valor) {
        float saldoFinal = saldo - valor;
        if (saldoFinal - saldoFinal * taxaOperacao >= 0) {
            setSaldo(saldoFinal);
            return setSaldo(saldo - (saldo * getTaxaOperacao()));
        } else {
            return false;
        }
    }
}
