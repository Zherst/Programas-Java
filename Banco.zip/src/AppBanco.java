public class AppBanco {
    static void depositaValor(float valor, Conta conta)
    {
        conta.depositar(valor);
    }

    static void sacaValor(float valor, Conta conta)
    {
        if(conta.sacar(valor)){
            System.out.println("Valor de " + valor + " sacado com sucesso.");
        }
        else System.out.println("Valor negado.");
    }

    static void imprimeSaldo(Conta conta)
    {
        System.out.println("Saldo na Conta: " +  conta.getSaldo());
    }
}
