public abstract class Conta {
    protected float saldo;

    public float getSaldo() { return saldo;}

    public boolean setSaldo(float saldo)
    {
        if (saldo >= 0) {
            this.saldo =saldo;
            return true;
        }
        else return false;
    }

    public Conta(float saldo)
    {
        this.saldo = saldo;
    }

    abstract public boolean depositar(float valor);

    abstract public boolean sacar(float valor);
}
