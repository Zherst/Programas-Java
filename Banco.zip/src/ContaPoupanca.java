public class ContaPoupanca extends Conta{

    public ContaPoupanca(float saldo)
    {
        super(saldo);
    }

    @Override
    public boolean depositar(float valor) {
        if (valor >= 0)
        {
            return setSaldo(saldo + valor);
        }
        else {
            return false;
        }
    }

    @Override
    public boolean sacar(float valor) {
        if (saldo - valor >= 0) {
            return setSaldo(saldo - valor);
        } else {
            return false;
        }
    }
}
